//
//  ViewController.swift
//  caculater
//
//  Created by Fuqiang on 2018/11/15.
//  Copyright © 2018 Fuqiang . All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    

    @IBOutlet weak var lable: UILabel!
    //用户是否已经输入数字，由于Swift的变量必须负初始值，所以设为false
    var userIsInTheMiddleOfTypingANumber:Bool = false
    @IBAction func appendDigit(sender: UIButton){
        let digit = sender.currentTitle!//直接获取Button的数字
        //若已输入过数字，则直接往display中添加数字，否则直接现实新点击数字，去除原始0的操作
        if userIsInTheMiddleOfTypingANumber{
            lable.text = lable.text! + digit
        }else{
            lable.text = digit
            userIsInTheMiddleOfTypingANumber = true
        }
    }
    //对数字进行运算
    @IBAction func operate(sender: UIButton) {
        let operation = sender.currentTitle!
        if userIsInTheMiddleOfTypingANumber{
            enter()
        }
        switch operation{
        case "×": performOperation { $0 * $1 }
        case "÷": performOperation { $1 / $0 }
        case "+": performOperation { $0 + $1 }
        case "−": performOperation { $1 - $0 }
        default: break
            
        }
    }
    func performOperation(operation: (Double,Double) -> Double){
        if operandStack.count >= 2 {
            displayValue = operation(operandStack.removeLast(),operandStack.removeLast())
            enter()
        }
        
    }
    private func performOperation(operation: (Double) -> Double){
        if operandStack.count >= 1 {
            displayValue = operation(operandStack.removeLast())
            enter()
        }
        
    }
    var operandStack = Array<Double>()
    
    //若用户点击enter，则将相应数字添加至数组Array中
    @IBAction func enter() {
        userIsInTheMiddleOfTypingANumber = false
        operandStack.append(displayValue)
        print("operandStack = \(operandStack)")
    }
    var displayValue: Double {
        get{
            return NumberFormatter().number(from: lable.text!)!.doubleValue
        }
        set{
            lable.text = "\(newValue)"
            userIsInTheMiddleOfTypingANumber = false
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    
}

